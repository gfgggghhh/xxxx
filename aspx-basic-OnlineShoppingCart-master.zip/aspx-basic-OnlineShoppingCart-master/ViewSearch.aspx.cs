using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ViewSearch : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       // test();
    }
    //public void test() 
    //{
    //    if (Session["kindid"] = null && Session["name"] = null)
    //    {
    //        Label1.Text = "Can not found products"
    //    }
    //    else 
    //    {
    //        Label1.Text = Session["kindid"].ToString();
    //        Label2.Text = Session["name"].ToString();
    //    }
    //}
}
